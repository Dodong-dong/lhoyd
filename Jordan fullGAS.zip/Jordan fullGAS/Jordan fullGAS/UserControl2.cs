﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jordan_fullGAS
{
    public partial class UserControl2 : UserControl
    {
        public UserControl2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Get the current value of the textbox
            string currentText = textBox1.Text;

            // Add some new text to the current value
            string newText = currentText + "1";

            // Set the new text as the value of the textbox
            textBox1.Text = newText;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Get the current value of the textbox
            string currentText = textBox1.Text;

            // Add some new text to the current value
            string newText = currentText + "2";

            // Set the new text as the value of the textbox
            textBox1.Text = newText;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // Get the current value of the textbox
            string currentText = textBox1.Text;

            // Add some new text to the current value
            string newText = currentText + "3";

            // Set the new text as the value of the textbox
            textBox1.Text = newText;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // Get the current value of the textbox
            string currentText = textBox1.Text;

            // Add some new text to the current value
            string newText = currentText + "4";

            // Set the new text as the value of the textbox
            textBox1.Text = newText;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // Get the current value of the textbox
            string currentText = textBox1.Text;

            // Add some new text to the current value
            string newText = currentText + "5";

            // Set the new text as the value of the textbox
            textBox1.Text = newText;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            // Get the current value of the textbox
            string currentText = textBox1.Text;

            // Add some new text to the current value
            string newText = currentText + "6";

            // Set the new text as the value of the textbox
            textBox1.Text = newText;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            // Get the current value of the textbox
            string currentText = textBox1.Text;

            // Add some new text to the current value
            string newText = currentText + "7";

            // Set the new text as the value of the textbox
            textBox1.Text = newText;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            // Get the current value of the textbox
            string currentText = textBox1.Text;

            // Add some new text to the current value
            string newText = currentText + "8";

            // Set the new text as the value of the textbox
            textBox1.Text = newText;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            // Get the current value of the textbox
            string currentText = textBox1.Text;

            // Add some new text to the current value
            string newText = currentText + "9";

            // Set the new text as the value of the textbox
            textBox1.Text = newText;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            // Get the current value of the textbox
            string currentText = textBox1.Text;

            // Add some new text to the current value
            string newText = currentText + "0";

            // Set the new text as the value of the textbox
            textBox1.Text = newText;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            double liters = Convert.ToDouble(textBox1.Text);
            double fuelPrice = 40;
            double totalCost = fuelPrice * liters;

            label1.Text = $"The total cost is {totalCost:f}.";
        }
    }
}
